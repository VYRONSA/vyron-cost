"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ClipboardList, PackageCheck, AlertTriangle, Truck, Archive } from "lucide-react";
import {
  VyronPremiumControlPanel,
  VyronPremiumFooterStrip,
  VyronPremiumFormulaCard,
  VyronPremiumHeroBanner,
  VyronPremiumIntelligencePanel,
  VyronPremiumMetricCard,
  VyronPremiumSectionHeading,
  VyronPremiumSpotlightQuote,
} from "@/components/vyron-premium/VyronPremiumSprint";
import { VYRON_DOMAIN_QUOTES, VYRON_DOMAIN_INTELLIGENCE } from "@/components/vyron-premium/VyronPremiumTheme";

type Stats = {
  openPos: number;
  pendingApproval: number;
  partiallyReceived: number;
  closedPos: number;
  backOrders: number;
  poVariances: number;
};

const procurementQuotes = VYRON_DOMAIN_QUOTES.procurement;

export default function PurchaseOrderDashboardClient() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/procurement/stats", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setStats(d.stats);
      })
      .catch(() => setStats(null));
  }, []);

  const cards = [
    { label: "Open POs", value: stats?.openPos, icon: ClipboardList, href: "/purchase-orders/list" },
    { label: "Pending Approval", value: stats?.pendingApproval, icon: AlertTriangle, href: "/purchase-orders/approvals" },
    { label: "Partially Received", value: stats?.partiallyReceived, icon: Truck, href: "/purchase-orders/list?status=Partially Received" },
    { label: "Closed POs", value: stats?.closedPos, icon: Archive, href: "/purchase-orders/list?status=Closed" },
    { label: "Back Orders", value: stats?.backOrders, icon: PackageCheck, href: "/purchase-orders/back-orders" },
    { label: "PO Variances", value: stats?.poVariances, icon: AlertTriangle, href: "/purchase-orders/list" },
  ];

  const actions = (
    <>
      <Link href="/purchase-orders/new" className="rounded-2xl bg-violet-700 px-5 py-3 text-sm font-black text-white shadow-lg shadow-violet-500/30">
        + New Purchase Order
      </Link>
      <Link href="/goods-receipts" className="rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-black text-white shadow-lg">
        GRN Dashboard
      </Link>
      <Link href="/goods-receipts/new" className="rounded-2xl border border-violet-200 bg-white px-5 py-3 text-sm font-black text-violet-800">
        New GRN
      </Link>
      <Link href="/purchase-orders/settings" className="rounded-2xl border border-violet-200 bg-white px-5 py-3 text-sm font-black text-violet-800">
        PO Approval Settings
      </Link>
    </>
  );

  return (
    <section className="grid gap-8">
      <VyronPremiumHeroBanner
        visualVariant="procurement"
        badge="Premium Procurement Workspace"
        title="Purchase Orders"
        subtitle="PROCUREMENT CONTROL — PO LIFECYCLE, GRN AND 3-WAY MATCHING"
        outcomes={["Control costs", "Approve POs", "Match GRNs", "Reduce risk"]}
      />

      <VyronPremiumControlPanel title="Purchase Order Control" actions={actions} quotes={procurementQuotes} />

      <div className="grid gap-4 lg:grid-cols-2">
        <VyronPremiumFormulaCard
          variant="dark"
          eyebrow="3-way match"
          title="Procurement reconciliation"
          formulas={[
            { label: "PO Total", formula: "Σ ordered qty × unit price" },
            { label: "GRN Total", formula: "Σ received qty × PO unit cost" },
            { label: "Invoice Variance", formula: "Supplier invoice − GRN value" },
          ]}
        />
        <VyronPremiumIntelligencePanel eyebrow="Procurement Intelligence" title="What to watch" items={VYRON_DOMAIN_INTELLIGENCE.procurement} />
      </div>

      <VyronPremiumSectionHeading eyebrow="Live metrics" title="Live Procurement Snapshot" subtitle="Open POs, approvals, receipts and variances at a glance." />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((card) => (
          <VyronPremiumMetricCard key={card.label} label={card.label} value={card.value ?? "…"} href={card.href} icon={<card.icon size={28} />} />
        ))}
      </div>

      <VyronPremiumSpotlightQuote quote={procurementQuotes[0].quote} attribution="Procurement Discipline" />
      <VyronPremiumFooterStrip />
    </section>
  );
}
