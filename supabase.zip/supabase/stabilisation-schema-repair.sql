-- STABILISATION: safe schema repair — idempotent, safe to re-run
-- Run after vyron-cost-demo-schema-catchup.sql if columns are still missing

-- Ensure base tables exist (minimal stubs if migrations were skipped)
create table if not exists public.vyron_supplier_line_item_mappings (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.vyron_cost_companies(id) on delete cascade,
  supplier_name text not null,
  source_description text not null,
  source_description_normalized text,
  entity_type text,
  entity_id uuid,
  entity_name text,
  confidence_score numeric(5,2) default 0,
  usage_count int not null default 0,
  last_seen_at timestamptz default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vyron_supplier_price_history (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.vyron_cost_companies(id) on delete cascade,
  supplier_name text,
  document_id uuid references public.vyron_documents(id) on delete set null,
  entity_type text,
  entity_id uuid,
  entity_name text,
  new_price numeric(14,4),
  created_at timestamptz not null default now()
);

create table if not exists public.vyron_document_approval_rules (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.vyron_cost_companies(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Required columns (reported missing)
alter table public.vyron_supplier_line_item_mappings
  add column if not exists disabled boolean not null default false,
  add column if not exists supplier_vat_number text,
  add column if not exists source_sku text,
  add column if not exists source_sku_normalized text,
  add column if not exists unit text,
  add column if not exists last_approved_price numeric(14,4),
  add column if not exists approved_by text,
  add column if not exists approved_at timestamptz,
  add column if not exists last_document_id uuid references public.vyron_documents(id) on delete set null,
  add column if not exists match_source text;

alter table public.vyron_supplier_price_history
  add column if not exists invoice_number text,
  add column if not exists invoice_date date,
  add column if not exists item_description text,
  add column if not exists previous_price numeric(14,4),
  add column if not exists price_difference numeric(14,4),
  add column if not exists percentage_change numeric(10,4),
  add column if not exists change_percent numeric(10,4),
  add column if not exists price_movement text,
  add column if not exists approved_by text,
  add column if not exists approved_at timestamptz,
  add column if not exists supplier_id uuid references public.vyron_cost_suppliers(id) on delete set null;

alter table public.vyron_document_approval_rules
  add column if not exists require_purchase_order boolean not null default false,
  add column if not exists require_supplier boolean not null default true,
  add column if not exists require_invoice_number boolean not null default true,
  add column if not exists require_invoice_date boolean not null default true,
  add column if not exists require_vat boolean not null default true,
  add column if not exists require_matched_line_items boolean not null default true,
  add column if not exists allow_ignored_lines boolean not null default true,
  add column if not exists allow_rounding_difference boolean not null default true,
  add column if not exists max_variance_percent numeric(8,4) not null default 2,
  add column if not exists supervisor_override_required_above_variance boolean not null default true,
  add column if not exists block_unmapped_lines boolean not null default false;

create index if not exists idx_vyron_supplier_line_mappings_disabled
  on public.vyron_supplier_line_item_mappings (tenant_id, supplier_name, disabled);

create index if not exists idx_vyron_supplier_price_history_invoice
  on public.vyron_supplier_price_history (tenant_id, invoice_number, created_at desc);
