"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import VyronCostAiShell from "@/components/VyronCostAiShell";

export default function BackOrdersPage() {
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);

  useEffect(() => {
    fetch("/api/back-orders")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setRows(d.backOrders || []);
      });
  }, []);

  return (
    <VyronCostAiShell title="Back Orders" subtitle="Outstanding quantities from partial receipts">
      <section className="rounded-[2rem] border border-violet-100 bg-white p-6">
        <Link href="/purchase-orders" className="text-xs font-black text-violet-700">
          ← PO Dashboard
        </Link>
        <table className="mt-4 min-w-full text-sm">
          <thead className="text-xs font-black uppercase text-slate-500">
            <tr>
              <th className="py-2">Supplier</th>
              <th>Item</th>
              <th>Outstanding</th>
              <th>Expected</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={String(row.id)} className="border-t">
                <td className="py-2">{String(row.supplier_name_snapshot)}</td>
                <td className="font-bold">{String(row.item_name)}</td>
                <td>{Number(row.outstanding_qty)}</td>
                <td>{String(row.expected_date || "—")}</td>
                <td>{String(row.status)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 ? <p className="mt-4 text-sm text-slate-500">No open back orders.</p> : null}
      </section>
    </VyronCostAiShell>
  );
}
