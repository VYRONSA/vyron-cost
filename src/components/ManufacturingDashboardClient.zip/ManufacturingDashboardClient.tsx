"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { Factory, AlertTriangle, TrendingDown, Package } from "lucide-react";
import { formatMoney } from "@/lib/vyron-cost-data";
import { poApiWorkspaceContext } from "@/lib/vyron-po-api-context";
import {
  VyronPremiumFooterStrip,
  VyronPremiumFormulaCard,
  VyronPremiumHeroBanner,
  VyronPremiumInsightCard,
  VyronPremiumInsightsPanel,
  VyronPremiumMetricCard,
  VyronPremiumSectionHeading,
  VyronPremiumSpotlightQuote,
} from "@/components/vyron-premium/VyronPremiumSprint";
import { VYRON_DOMAIN_QUOTES } from "@/components/vyron-premium/VyronPremiumTheme";

type Stats = {
  productionThisWeek: number;
  productionThisMonth: number;
  productionCost: number;
  yieldPct: number;
  wastagePct: number;
  ingredientUsageValue: number;
  packagingUsageValue: number;
  finishedGoodsProduced: number;
  productionVariances: number;
  productionEfficiency: number;
  finishedGoodsValue: number;
  activeRuns: number;
};

type Insight = { severity: string; category: string; message: string; href?: string };

export default function ManufacturingDashboardClient() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [insights, setInsights] = useState<Insight[]>([]);

  const refresh = useCallback(() => {
    const { query } = poApiWorkspaceContext();
    fetch(`/api/production/stats${query}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setStats(d.stats);
      });
    fetch(`/api/production/insights${query}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setInsights(d.insights);
      });
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const cards = [
    ["Production This Week", stats ? String(stats.productionThisWeek) : "…", "/manufacturing/history"],
    ["Production This Month", stats ? String(stats.productionThisMonth) : "…", "/manufacturing/history"],
    ["Production Cost", stats ? formatMoney(stats.productionCost) : "…", "/manufacturing/variances"],
    ["Yield %", stats ? `${stats.yieldPct}%` : "…", "/manufacturing/variances"],
    ["Wastage %", stats ? `${stats.wastagePct}%` : "…", "/manufacturing/variances"],
    ["Ingredient Usage", stats ? formatMoney(stats.ingredientUsageValue) : "…", "/inventory/stock?entityType=ingredient"],
    ["Packaging Usage", stats ? formatMoney(stats.packagingUsageValue) : "…", "/inventory/stock?entityType=packaging"],
    ["Finished Goods Produced", stats ? String(stats.finishedGoodsProduced) : "…", "/manufacturing/finished-goods"],
    ["Production Variances", stats ? String(stats.productionVariances) : "…", "/manufacturing/variances"],
    ["Production Efficiency", stats ? `${stats.productionEfficiency}%` : "…", "/manufacturing/variances"],
  ];

  return (
    <section className="grid gap-8">
      <VyronPremiumHeroBanner
        visualVariant="manufacturing"
        badge="Premium Production Workspace"
        title="Manufacturing Control"
        subtitle="Production output, batch cost, yield, wastage and finished goods from live runs — every batch is a financial event."
        outcomes={[
          "Monitor weekly and monthly production output",
          "Track yield, wastage and batch cost",
          "See finished goods inventory value",
          "Act on AI production insights",
        ]}
        quotes={[
          {
            label: "Yield discipline",
            quote: "What leaves the line must match what the BOM promised — variance is margin leaking.",
          },
          {
            label: "Cost truth",
            quote: "Ingredient and packaging usage at true cost reveal whether production protects wealth.",
          },
        ]}
      >
        <Link href="/manufacturing/runs/new" className="rounded-2xl bg-white px-5 py-3 text-sm font-black text-violet-900 shadow-lg">
          New Production Run
        </Link>
        <Link href="/manufacturing/history" className="rounded-2xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-black text-white backdrop-blur-sm">
          Manufacturing History
        </Link>
        <Link href="/manufacturing/finished-goods" className="rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-black text-white shadow-lg shadow-emerald-900/20">
          Finished Goods
        </Link>
        <Link href="/recipes" className="rounded-2xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-black text-white backdrop-blur-sm">
          Recipes & BOM
        </Link>
      </VyronPremiumHeroBanner>

      <VyronPremiumSectionHeading
        eyebrow="Live metrics"
        title="Production snapshot"
        subtitle="Tap any card to drill into history, variances or stock."
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {cards.map(([label, value, href]) => (
          <VyronPremiumMetricCard
            key={label}
            label={label}
            value={value}
            href={href}
            icon={<Factory size={22} />}
          />
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <VyronPremiumFormulaCard
          eyebrow="Yield & wastage"
          title="How production performance is measured"
          formulas={[
            { label: "Yield %", formula: "Actual output ÷ Planned output × 100" },
            { label: "Wastage %", formula: "Waste quantity ÷ Input quantity × 100" },
            { label: "Efficiency", formula: "Standard cost ÷ Actual cost × 100" },
          ]}
        />
        <VyronPremiumFormulaCard
          variant="light"
          eyebrow="Batch economics"
          title="Cost roll-up from the line"
          formulas={[
            { label: "Production Cost", formula: "Ingredient usage + packaging + labour + overhead" },
            { label: "Variance", formula: "Actual batch cost − Standard BOM cost" },
            { label: "FG Value", formula: "Finished units × weighted average unit cost" },
          ]}
        />
      </div>

      {stats ? (
        <div className="relative overflow-hidden rounded-[2rem] bg-[#07110d] p-8 text-white shadow-[0_24px_60px_rgba(6,20,14,0.28)]">
          <div className="pointer-events-none absolute -right-12 top-0 h-40 w-40 rounded-full bg-emerald-400/10 blur-3xl" />
          <div className="relative flex flex-wrap items-center gap-6">
            <Package className="text-emerald-400" size={32} />
            <div className="flex-1">
              <div className="text-[10px] font-black uppercase tracking-[0.18em] text-emerald-300">Finished Goods Inventory Value</div>
              <div className="mt-1 text-4xl font-black">{formatMoney(stats.finishedGoodsValue)}</div>
            </div>
            <div className="text-right">
              <div className="text-xs font-bold uppercase tracking-[0.12em] text-slate-400">Active runs</div>
              <div className="mt-1 text-3xl font-black text-amber-300">{stats.activeRuns}</div>
            </div>
          </div>
        </div>
      ) : null}

      {insights.length > 0 ? (
        <VyronPremiumInsightsPanel title="AI Production Insights" icon={<AlertTriangle size={18} />}>
          {insights.map((item, i) => (
            <VyronPremiumInsightCard key={i} category={item.category} message={item.message} href={item.href} />
          ))}
        </VyronPremiumInsightsPanel>
      ) : (
        <div className="rounded-[2rem] border border-slate-100 bg-white p-8 text-sm font-semibold text-slate-500 shadow-[0_18px_50px_rgba(81,63,190,0.06)]">
          <TrendingDown className="mb-3 text-slate-400" size={28} />
          <VyronPremiumSectionHeading
            title="Insights will appear here"
            subtitle="Complete production runs to generate yield, wastage and cost insights."
          />
        </div>
      )}

      <VyronPremiumSpotlightQuote quote={VYRON_DOMAIN_QUOTES.manufacturing[0]?.quote ?? "Every batch is a financial event."} attribution={VYRON_DOMAIN_QUOTES.manufacturing[0]?.label ?? "Production discipline"} />
      <VyronPremiumFooterStrip />
    </section>
  );
}
